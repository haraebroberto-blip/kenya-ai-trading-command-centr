import express from "express";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import { rateLimit } from "express-rate-limit";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.APP_BASE_URL;
const CLIENT_ID = process.env.DERIV_CLIENT_ID;
const SESSION_SECRET = process.env.SESSION_SECRET;
const COOKIE_NAME = "kenya_demo_session";
const AUTH_URL = "https://auth.deriv.com/oauth2/auth";
const TOKEN_URL = "https://auth.deriv.com/oauth2/token";
const API_BASE = "https://api.derivws.com";

if (!BASE_URL || !CLIENT_ID || !SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error("Missing APP_BASE_URL, DERIV_CLIENT_ID, or a SESSION_SECRET of at least 32 characters.");
  process.exit(1);
}
if (!BASE_URL.startsWith("https://") && !BASE_URL.startsWith("http://localhost")) {
  console.error("APP_BASE_URL must use HTTPS (localhost is allowed for development).");
  process.exit(1);
}

app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(cookieParser());

const sessions = new Map(); // In-memory only: restart logs the user out; access tokens are never written to disk.
const oauthAttempts = new Map();
const CALLBACK = `${BASE_URL.replace(/\/$/, "")}/auth/callback`;

function randomHex(bytes = 32) { return crypto.randomBytes(bytes).toString("hex"); }
function b64url(buf) { return Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
function sign(value) {
  return crypto.createHmac("sha256", SESSION_SECRET).update(value).digest("hex");
}
function setSessionCookie(res, id) {
  const value = `${id}.${sign(id)}`;
  res.cookie(COOKIE_NAME, value, {
    httpOnly: true, secure: BASE_URL.startsWith("https://"),
    sameSite: "lax", path: "/", maxAge: 8 * 60 * 60 * 1000
  });
}
function getSession(req) {
  const raw = req.cookies[COOKIE_NAME];
  if (!raw) return null;
  const dot = raw.lastIndexOf(".");
  if (dot < 1) return null;
  const id = raw.slice(0, dot), sig = raw.slice(dot + 1);
  const expected = sign(id);
  if (sig.length !== expected.length ||
      !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  const session = sessions.get(id);
  if (!session || session.expiresAt < Date.now()) {
    sessions.delete(id); return null;
  }
  return session;
}
function requireSession(req, res, next) {
  const session = getSession(req);
  if (!session) return res.status(401).json({ connected: false, error: "Not connected. Please connect your Deriv Virtual account again." });
  req.sessionData = session;
  next();
}
const authLimiter = rateLimit({ windowMs: 60_000, limit: 10, standardHeaders: true, legacyHeaders: false });

app.get("/health", (_req, res) => res.json({ ok: true, service: "Kenya AI Trading Command Centre", mode: "demo-auth-scaffold" }));
app.get("/", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.get("/auth/deriv", authLimiter, (req, res) => {
  const state = randomHex(24);
  const verifier = b64url(crypto.randomBytes(48));
  const challenge = b64url(crypto.createHash("sha256").update(verifier).digest());
  oauthAttempts.set(state, { verifier, createdAt: Date.now() });
  // Expire old, unused attempts.
  for (const [key, value] of oauthAttempts) if (Date.now() - value.createdAt > 10 * 60 * 1000) oauthAttempts.delete(key);

  const params = new URLSearchParams({
    response_type: "code",
    client_id: CLIENT_ID,
    redirect_uri: CALLBACK,
    scope: "trade",
    state,
    code_challenge: challenge,
    code_challenge_method: "S256"
  });
  res.redirect(`${AUTH_URL}?${params.toString()}`);
});

app.get("/auth/callback", authLimiter, async (req, res) => {
  const { code, state, error } = req.query;
  if (error) return res.status(400).send("Deriv authorization was cancelled or denied. You can close this page and try again.");
  if (typeof code !== "string" || typeof state !== "string") return res.status(400).send("Missing authorization response.");
  const attempt = oauthAttempts.get(state);
  oauthAttempts.delete(state);
  if (!attempt || Date.now() - attempt.createdAt > 10 * 60 * 1000) return res.status(400).send("Authorization state expired or did not match. Please try connecting again.");

  try {
    const body = new URLSearchParams({
      grant_type: "authorization_code",
      client_id: CLIENT_ID,
      code,
      code_verifier: attempt.verifier,
      redirect_uri: CALLBACK
    });
    const tokenResponse = await fetch(TOKEN_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body
    });
    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok || !tokenData.access_token) {
      console.error("OAuth token exchange failed:", tokenResponse.status);
      return res.status(502).send("Deriv authorization could not be completed. No token was saved. Please try again.");
    }

    const id = randomHex(32);
    sessions.set(id, {
      accessToken: tokenData.access_token,
      expiresAt: Date.now() + (Number(tokenData.expires_in) || 0) * 1000,
      createdAt: Date.now()
    });
    setSessionCookie(res, id);
    res.redirect("/?connected=1");
  } catch {
    res.status(502).send("Could not reach Deriv. Please try again later.");
  }
});

app.get("/api/status", (req, res) => {
  const s = getSession(req);
  res.json({ connected: Boolean(s), expiresAt: s ? new Date(s.expiresAt).toISOString() : null, mode: "demo-only scaffold" });
});

app.get("/api/account", requireSession, async (req, res) => {
  if (req.sessionData.expiresAt <= Date.now()) {
    return res.status(401).json({ connected: false, error: "Deriv session expired. Please reconnect." });
  }
  try {
    const response = await fetch(`${API_BASE}/trading/v1/options/accounts`, {
      headers: { Authorization: `Bearer ${req.sessionData.accessToken}` }
    });
    const data = await response.json();
    if (response.status === 401) return res.status(401).json({ connected: false, error: "Deriv authorization expired or was rejected. Please reconnect." });
    if (!response.ok) return res.status(502).json({ error: "Deriv account lookup failed. Check app permissions and try again." });

    // Return only safe account metadata. Never return tokens or raw API payloads to the browser.
    const accounts = Array.isArray(data?.data) ? data.data : (Array.isArray(data?.accounts) ? data.accounts : []);
    const safe = accounts.map(a => ({
      account_type: a.account_type ?? a.type ?? null,
      currency: a.currency ?? null,
      is_virtual: a.is_virtual ?? a.virtual ?? null,
      status: a.status ?? null
    }));
    res.json({ accounts: safe, verification: "Review the returned account metadata and confirm the Virtual account before enabling any trading feature." });
  } catch {
    res.status(502).json({ error: "Could not contact Deriv account service." });
  }
});

app.post("/auth/logout", (req, res) => {
  const raw = req.cookies[COOKIE_NAME];
  if (raw) {
    const id = raw.slice(0, raw.lastIndexOf("."));
    sessions.delete(id);
  }
  res.clearCookie(COOKIE_NAME, { httpOnly: true, secure: BASE_URL.startsWith("https://"), sameSite: "lax", path: "/" });
  res.json({ ok: true });
});

// Explicitly no order-placement routes in this version.
app.use((_req, res) => res.status(404).json({ error: "Not found" }));

app.listen(PORT, () => console.log(`Kenya AI backend listening on ${PORT}`));
